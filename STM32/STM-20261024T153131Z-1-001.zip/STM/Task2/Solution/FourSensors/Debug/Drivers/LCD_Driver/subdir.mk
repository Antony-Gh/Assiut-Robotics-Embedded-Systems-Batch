################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/LCD_Driver/LCD_config.c \
../Drivers/LCD_Driver/LCD_prog.c 

OBJS += \
./Drivers/LCD_Driver/LCD_config.o \
./Drivers/LCD_Driver/LCD_prog.o 

C_DEPS += \
./Drivers/LCD_Driver/LCD_config.d \
./Drivers/LCD_Driver/LCD_prog.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/LCD_Driver/%.o Drivers/LCD_Driver/%.su Drivers/LCD_Driver/%.cyclo: ../Drivers/LCD_Driver/%.c Drivers/LCD_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-LCD_Driver

clean-Drivers-2f-LCD_Driver:
	-$(RM) ./Drivers/LCD_Driver/LCD_config.cyclo ./Drivers/LCD_Driver/LCD_config.d ./Drivers/LCD_Driver/LCD_config.o ./Drivers/LCD_Driver/LCD_config.su ./Drivers/LCD_Driver/LCD_prog.cyclo ./Drivers/LCD_Driver/LCD_prog.d ./Drivers/LCD_Driver/LCD_prog.o ./Drivers/LCD_Driver/LCD_prog.su

.PHONY: clean-Drivers-2f-LCD_Driver

