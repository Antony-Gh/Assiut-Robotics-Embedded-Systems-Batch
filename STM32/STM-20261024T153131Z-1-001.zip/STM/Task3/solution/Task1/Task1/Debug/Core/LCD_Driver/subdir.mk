################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/LCD_Driver/LCD_config.c \
../Core/LCD_Driver/LCD_prog.c 

OBJS += \
./Core/LCD_Driver/LCD_config.o \
./Core/LCD_Driver/LCD_prog.o 

C_DEPS += \
./Core/LCD_Driver/LCD_config.d \
./Core/LCD_Driver/LCD_prog.d 


# Each subdirectory must supply rules for building sources it contributes
Core/LCD_Driver/%.o Core/LCD_Driver/%.su Core/LCD_Driver/%.cyclo: ../Core/LCD_Driver/%.c Core/LCD_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-LCD_Driver

clean-Core-2f-LCD_Driver:
	-$(RM) ./Core/LCD_Driver/LCD_config.cyclo ./Core/LCD_Driver/LCD_config.d ./Core/LCD_Driver/LCD_config.o ./Core/LCD_Driver/LCD_config.su ./Core/LCD_Driver/LCD_prog.cyclo ./Core/LCD_Driver/LCD_prog.d ./Core/LCD_Driver/LCD_prog.o ./Core/LCD_Driver/LCD_prog.su

.PHONY: clean-Core-2f-LCD_Driver

