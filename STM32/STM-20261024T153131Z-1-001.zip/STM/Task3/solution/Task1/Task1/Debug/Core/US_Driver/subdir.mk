################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/US_Driver/US_prog.c 

OBJS += \
./Core/US_Driver/US_prog.o 

C_DEPS += \
./Core/US_Driver/US_prog.d 


# Each subdirectory must supply rules for building sources it contributes
Core/US_Driver/%.o Core/US_Driver/%.su Core/US_Driver/%.cyclo: ../Core/US_Driver/%.c Core/US_Driver/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-US_Driver

clean-Core-2f-US_Driver:
	-$(RM) ./Core/US_Driver/US_prog.cyclo ./Core/US_Driver/US_prog.d ./Core/US_Driver/US_prog.o ./Core/US_Driver/US_prog.su

.PHONY: clean-Core-2f-US_Driver

