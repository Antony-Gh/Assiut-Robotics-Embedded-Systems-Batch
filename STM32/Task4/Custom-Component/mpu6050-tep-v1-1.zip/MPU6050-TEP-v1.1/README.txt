MPU6050 MOTION SENSOR (GY-521) LIBRARY FOR PROTEUS - V1.1
Designed by The Engineering Projects
www.TheEngineeringProjects.com

IMPORTANT LINKS
Article (read it first - pictures, step by step, every feature explained):
  https://www.theengineeringprojects.com/2026/09/mpu6050-proteus-library.html
Report a bug or suggest a feature (our forum):
  https://www.theengineeringprojects.com/forum/category/mpu6050-proteus-library
The demo uses our TEP Serial Monitor Advance (included) instead of Proteus's
Virtual Terminal - its own article:
  https://www.theengineeringprojects.com/2026/10/serial-monitor-advance-proteus-library.html
Support us (the libraries are free):
  https://www.theengineeringprojects.com/donate

FILE STRUCTURE
MPU6050-TEP-v1.1/
|-- Proteus Library Files/
|   |-- ArduinoV3TEP.IDX                          0.8 KB   its index -> LIBRARY folder
|   |-- ArduinoV3TEP.LIB                         95.6 KB   TEP Arduino UNO (demo) -> LIBRARY folder
|   |-- TEPMPU6050.LIB                          130.9 KB   MPU6050 Simple + Advance (2 devices) -> LIBRARY
|   |-- TEPSERIALMON.LIB                         11.1 KB   TEP Serial Monitor Advance -> LIBRARY folder
|-- Proteus Model Files/
|   |-- TEPMPU6050.DLL                          537.0 KB   the TEP I2C sensor model -> MODELS
|   |-- TEPSERIALMON.DLL                        978.0 KB   Serial Monitor model -> MODELS folder
|-- Proteus Simulation/
|   |-- MPU6050_Demo.hex                         54.2 KB   both UNOs (the demo sketch v1.1)
|   |-- MPU6050-ArduinoUnoV3.pdsprj              33.7 KB   demo: UNO 1 + MPU6050 Simple, UNO 2 + Advance
|   |-- TEPMPU6050.DLL                          537.0 KB   copy of the model so the demo runs as is
|   |-- TEPSERIALMON.DLL                        978.0 KB   copy of the monitor model
|-- Arduino Code/
|   |-- MPU6050_Demo/MPU6050_Demo.ino             7.6 KB   sketch (source of the .hex)
|   |-- libraries/Adafruit_MPU6050/              57.4 KB   Adafruit MPU6050 2.2.9, BSD, 11 files
|   |-- libraries/Adafruit_BusIO/                77.0 KB   Adafruit BusIO 1.17.4, MIT, 24 files
|   |-- libraries/Adafruit_Unified_Sensor/       40.6 KB   Unified Sensor 1.1.15, Apache 2.0, 6 files
|-- README.txt                                  ~27.5 KB   this file
Total: 3.48 MB (unzipped). The C++ source code of the model is not included.

WHAT IS IT?
A simulation model of the InvenSense MPU-6050 6-axis motion sensor (3-axis
accelerometer + 3-axis gyroscope + temperature) on the common blue GY-521
breakout, for Proteus 8. Your Arduino talks to it over I2C exactly as to the real
chip (address 0x68, or 0x69 with AD0 high) and the popular Adafruit MPU6050
library runs unmodified: begin, getEvent, setAccelerometerRange, setGyroRange,
setFilterBandwidth, setSampleRateDivisor, setHighPassFilter, the motion
interrupt (setMotionInterrupt, setMotionDetectionThreshold / Duration,
getMotionInterruptStatus), setInterruptPinLatch / Polarity, sleep, reset. The
model has the MPU-6050's register map: the four accelerometer and gyro ranges,
the digital low-pass filter WITH its delay (v1.1), the sample-rate divider (1 or
8 kHz), the 1024-byte FIFO, the motion detector and the INT pin. You set the
acceleration (in g, gravity included - lying flat = 1 g on Z), the rotation and
the die temperature with sliders, presets (FLAT, TILT 30, ROLL 45, UPSIDE DOWN,
SHAKE, SPIN) or by clicking the artificial horizon above the board.
The part looks like the GY-521: the blue board, the two mounting holes, the
MPU-6050 in the centre with the tantalum capacitor below it, the 662K regulator,
the X / Y / Z axis glyph and the big GY-521. Above the board sits an animated
instrument window: an artificial horizon that tilts and rolls with the sensor,
bars for the three gyro axes and the temperature. On the board: a red PWR LED, a
blue I2C LED that flashes for every I2C transaction to this sensor and an amber
INT LED that lights while the INT pin is active - TEP additions (the real GY-521
has only a small power LED) - and the live I2C address (0x68 / 0x69).

TWO DEVICES IN ONE LIBRARY (search "MPU6050" in Pick Devices):
  MPU6050 Simple    device MPU6050TEP     "MPU6050 Motion Sensor (GY-521) - Simple"
                    On-Sheet Panel: a control panel on the schematic next to the
                    board - six presets, the seven sliders of v1.0 (drag them:
                    ACCEL X / Y / Z, GYRO X / Y / Z, TEMPERATURE) and what your
                    sketch READ over I2C (decoded by the model: "SKETCH READ: 0.00
                    0.00 1.00 G ..."), the tilt it shows and the motion detector's
                    state. The red X in the panel's header closes it, the PANEL
                    button on the board opens it again. Your v1.0 designs keep
                    working with this device.
  MPU6050 Advance   device MPU6050ADVTEP  "MPU6050 Motion Sensor (GY-521) - Advance"
                    Pop-Up Panel: only the board on the schematic; at Run a TEP
                    pop-up window opens - the same look as the TEP Serial Monitor
                    (move it by its header, resize it, minimise it). The tabs
                    Sensor and Test sit in the header; the gear and ? icons open
                    Settings and Help; the palette icon switches the theme:
                      Sensor    the live horizon (click it to tilt the sensor), the
                                presets, a click-slider with - / + for every input,
                                and what the Arduino read over I2C (the values, the
                                tilt, the ranges, the filter, the FIFO, the INT pin,
                                the I2C address and the measured SCL clock)
                      Test      four tools measured on the model with your sketch:
                                I2C check, Timing, Step response, Orientation (see
                                THE TEST TOOLS below)
                      Settings  theme (TEP Dark / Light), text size, open at Run,
                                window size - remembered for your Windows user
                      Help      Help & Support like the TEP Serial Monitor: report a
                                bug, suggest a feature, article, user guide,
                                updates, donate, website, forum; Copy diagnostics
                                (the inputs, what was read, the registers, the last
                                transactions, the test results) for a bug report
                    The OPEN PANEL button on the board opens the window again
                    after you close it.
Both devices use the same model (TEPMPU6050.DLL) and the same properties.

NEW IN V1.1
* Two devices: MPU6050 Simple (panel on the sheet, close / open) and MPU6050
  Advance (pop-up window with the live horizon, four test tools, settings and
  help) - see above.
* Board: the real GY-521's look (royal blue, two holes, the chip in the centre,
  the 662K regulator, the axis glyph) with an animated instrument window above
  it (artificial horizon, gyro and temperature bars), PWR / I2C / INT LEDs
  (a TEP addition), the live I2C address, a PANEL / OPEN PANEL button and a
  SIMPLE / ADVANCE badge.
* Model - the digital low-pass filter now has its datasheet delay: DLPF_CFG 0 ..
  6 = 260 / 184 / 94 / 44 / 21 / 10 / 5 Hz with 0 / 2.0 / 3.0 / 4.9 / 8.5 / 13.8 /
  19.0 ms (accelerometer) and 0.98 / 1.9 / 2.8 / 4.8 / 8.3 / 13.4 / 18.6 ms (gyro),
  modelled as a first-order lag: after a 1 g step through the 5 Hz filter the
  output is 0.63 g after 19 ms (v1.0: no filter dynamics).
* Model - motion detection (a known gap of v1.0): MOT_THR (model: 2 mg per LSB),
  MOT_DUR (1 ms per LSB) and the digital high-pass filter (ACCEL_CONFIG: reset,
  5, 2.5, 1.25, 0.63 Hz, hold) on the 1 kHz accelerometer data; INT_ENABLE bit 6
  sets INT_STATUS bit 6 (MOT_INT) - the Adafruit motion_detection example works.
* Model - the INT pin follows INT_PIN_CFG: active high or low, push-pull or open
  drain, latched until INT_STATUS is read or a 50 us pulse per event (data
  ready, motion, FIFO overflow); a callback ends each pulse on time.
* Model - an I2C transaction log (every read / write decoded: "read
  ACCEL_XOUT_H -> 14 bytes", "write CONFIG = 04") and the measured SCL clock.
* The demo: ONE project with two UNOs - UNO 1 with MPU6050 Simple, UNO 2 with
  MPU6050 Advance - each with the TEP Serial Monitor Advance instead of the
  Virtual Terminal (U3 = UNO 1, U4 = UNO 2, quick buttons) and an LED on A0.
* The demo sketch (v1.1) keeps every v1.0 line and adds: the tilt line (pitch /
  roll from the accelerometer), a tilt alarm on the LED (more than 30 degrees,
  and 1 s after the motion interrupt), and the Serial Monitor commands HELP,
  STATUS, RANGE, GYRO, FILTER, RATE, MOTION ON / OFF, TILT ON / OFF. It prints
  nothing periodically except the readings.
* Version 1.1 everywhere; the C++ source code is no longer included (and
  neither is the Arduino AVR core archive - its GitHub link is below).

TEST STATUS
v1.1: verified in Proteus 8.5 on 8 Oct 2026 (the demo run from this package's
Proteus Simulation folder):
  * start-up: U3 "TEP MPU6050 Demo v1.1 - type HELP in the Serial Monitor", then
    Accel 0.00 / 0.00 / 1.00, Gyro 0 / 0 / 0 | T 25.0 C, Tilt 0 / 0; U2's pop-up
    opens without a Windows caption row;
  * U1 ROLL 45: "Accel g: 0.00, 0.71, 0.71", "Tilt: pitch 0.0, roll 45.0 deg",
    "Tilt alarm: ON (more than 30 deg)", LED D1 lit, the horizon rotated;
    MOTION ON + SHAKE: "Motion detected!" while it shakes, the amber INT LED lit;
  * U4 STATUS: "Status: +-16 g, +-2000 deg/s, filter 21 Hz, every 500 ms" /
    "  motion ON, tilt alarm off";
  * the four tools on U2: I2C check (WHO_AM_I 68, PWR_MGMT_1 01, CONFIG 04 =
    DLPF 21 Hz with 8.5 ms delay, GYRO / ACCEL_CONFIG 18, 389 transactions,
    0 NACKs, SCL 79 kHz measured, "read ACCEL_XOUT_H" 14 bytes in 1467 us);
    Timing 3 s (3000 samples every 1.00 ms, 6 reads every 499.9 ms, data age
    0.8 / 1.3 ms, 0 read twice); Step response (pitch, 3 steps: the first
    reading after 17 - 18 ms, 90 % after about 518 ms); Orientation (7 / 7,
    worst error 0.12 deg - nose down 30 reads -29.9; the shake: "motion INT off
    (type MOTION ON)", after MOTION ON 29 motion interrupts);
  * Settings and Help (8 live links); close + OPEN PANEL; the red X and PANEL;
  * a v1.0 design (the v1.0 release demo with this DLL): the v1.0 panel
    ("MPU6050 CONTROLS ... DRAG TO CHANGE"); ACCEL X to 10.99 g gave "Accel g:
    10.99, 0.00, 1.00" on its Virtual Terminal.
(After that run only the Test pages' layout changed - they fill the window, the
register table has one register per row: no behaviour, no numbers. PC-tested, to
be re-checked in Proteus. Later the same day, also PC-tested: while SHAKE runs,
the sliders it moves stay at the value you set, labelled "(base)", and say what
the sensor gets now ("SHAKE now 0.76 g"); the Step response waits until the
readings sit at the start value before step 1.)
PC tests (8 Oct 2026, this package's DLL / LIB / sketch):
  6390 automatic checks on a PC, 0 failed, plus the v1.0 test, unchanged and
  passing with the v1.1 model (MPU6050: official Adafruit driver, four ranges,
  seven channels, alternate address, FIFO and reset); 15 chip checks for v1.1
  (the DLPF delay, the sample rates, motion detection with the latched INT pin,
  the INT pin modes, data-ready pulses, the FIFO overflow); 76 on the complete
  Proteus model (the LIB (pins, properties, both devices), power, the PWR / I2C
  / INT LEDs, the address pin, the panel, red X / PANEL, OPEN PANEL, the pop-up
  pages and links, the decoded readings, the DLPF, the motion interrupt, the
  presets (SHAKE: the sliders keep the base and say what the sensor gets now),
  the four tools, a design with the v1.0 symbol); 27 with the real v1.1 demo
  sketch and the unmodified driver library on two UNOs (every v1.0 output line,
  the tilt line and alarm LED, every Serial Monitor command, the Timing / Step
  response / Orientation tools with the real sketch); 6272 on the rendered
  boards and pop-up windows (every page fits in TEP Dark and Light, at Large
  text and 150 % DPI; every tool's hint lines and every header state fit).
v1.0 (29 Sep 2026): the v1.0 demo was run in Proteus 8.5 by our team -
  acceleration, gyro and temperature sliders and the serial readings ("the
  MPU6050 works perfectly"); the v1.0 tests (the unmodified Adafruit MPU6050
  library over the bit-level I2C slave: four ranges, seven channels, the
  alternate address, the FIFO and reset) still pass with the v1.1 model.

INSTALLATION (about 2 minutes)
1. Close Proteus. Extract the WHOLE ZIP to a normal folder (e.g. Desktop).
2. Copy everything in "Proteus Library Files" (TEPMPU6050.LIB with both devices,
   TEPSERIALMON.LIB and the TEP Arduino UNO V3 library ArduinoV3TEP.LIB / .IDX
   used by the demo) to the LIBRARY folder of Proteus, for example:
     C:\Program Files (x86)\Labcenter Electronics\Proteus 8 Professional\LIBRARY
   (on some PCs: C:\ProgramData\Labcenter Electronics\Proteus 8 Professional\
   LIBRARY - use the folder that already holds Proteus's own .LIB files).
3. Copy TEPMPU6050.DLL and TEPSERIALMON.DLL from "Proteus Model Files" to the
   MODELS folder (...\Proteus 8 Professional\MODELS).
4. Updating from v1.0: replace TEPMPU6050.LIB and TEPMPU6050.DLL, and
   delete TEPMPU6050.IDX if there is one in the LIBRARY folder. A v1.0 design keeps
   its v1.0 symbol: it runs with the new model and shows the v1.0 panel (without
   the v1.1 board parts and the red X) - re-pick the part to get the v1.1 symbol.
5. Start Proteus. In Pick Devices (P) search "MPU6050": you get the Simple and
   the Advance device (category Sensors > Motion, as in v1.0).
The model DLL is the TEP I2C sensor family model: TEPMPU6050.DLL, TEPBMP280.DLL,
TEPMAX30102.DLL, TEPVL53L0X.DLL, TEPSHT31.DLL and TEPTCS34725.DLL are identical
files under the v1.0 names, so every v1.0 design finds its model.

RUN THE DEMO
"Proteus Simulation\MPU6050-ArduinoUnoV3.pdsprj" - keep MPU6050_Demo.hex and the
two DLLs beside the project.
  UNO 1 (ARD1): MPU6050 Simple (U1), Serial Monitor U3.
  UNO 2 (ARD2): MPU6050 Advance (U2), Serial Monitor U4.
  Both UNOs run MPU6050_Demo.hex. An LED (D1 / D2) with 220 ohm on A0 of each
  UNO: the tilt alarm.
  1. Press Run. Both monitor windows open (9600 baud) and so does U2's pop-up.
     U3 and U4 show "TEP MPU6050 - drag acceleration, gyro and temperature
     controls." and "TEP MPU6050 Demo v1.1 - type HELP in the Serial Monitor",
     then every 500 ms:
       Accel g: 0.00, 0.00, 1.00
       Gyro deg/s: 0.0, 0.0, 0.0 | T: 25.0 C
       Tilt: pitch 0.0, roll 0.0 deg
     The blue I2C LED on each board flashes with every read.
  2. U1: click TILT 30 on the panel (or drag ACCEL X) - the horizon above the
     board tilts, U3 prints "Accel g: -0.50, 0.00, 0.87" and "Tilt: pitch 30.0,
     roll 0.0 deg". ROLL 45 or UPSIDE DOWN: "Tilt alarm: ON (more than 30 deg)"
     and LED D1 lights; FLAT: "Tilt alarm: off". Click the horizon to tilt the
     sensor anywhere. Close the panel with its red X and open it with PANEL.
  3. U3 / U4 quick buttons: STATUS, MOTION ON (then click SHAKE: "Motion
     detected!", the amber INT LED and the LED on A0), RATE 200 (faster
     readings), HELP. Type RANGE 4, GYRO 500, FILTER 5, TILT OFF ...
  4. U2 (Advance): the Sensor page shows the same inputs and what the sketch
     read; the Test page has the four tools (below).
  5. Close U2's window and open it again with OPEN PANEL on the board.
Closed a monitor window? Click OPEN MONITOR on the monitor part.

WIRING (as in the v1.0 demo)
VCC -> supply, GND -> GND, SCL -> A5, SDA -> A4, AD0 -> GND (address 0x68; AD0
high = 0x69); XDA, XCL and INT not connected (INT is optional: it drives the INT
LED and can go to D2 for attachInterrupt).
In the sketch: Adafruit_MPU6050 sensor;  sensor.begin(0x68);  Serial 9600.
Serial Monitor RXD <- Arduino D1 (TX), Serial Monitor TXD -> Arduino D0 (RX),
Serial Monitor GND -> ground. RXD2 is not needed: I2C has no serial line to
watch. The alarm LED + 220 ohm from A0 to GND.
Pin order in Proteus: VCC GND SCL SDA XDA XCL AD0 INT (v1.0; the real GY-521
header has the same order).
REAL HARDWARE:
 * Supply: the GY-521 has a 3.3 V regulator (662K) - feed VCC with 5 V (or 3.3
   V) from the Arduino. The MPU-6050 itself is a 3.3 V part.
 * I2C pull-ups: the GY-521 has its own (2.2 k or 10 k to 3.3 V on most boards),
   so A4 / A5 need nothing else; a 5 V UNO reads the 3.3 V levels correctly.
 * Address: AD0 has a 4.7 k pull-down on the board (0x68); tie AD0 to VCC for
   0x69 - two MPU6050 on one bus need different AD0 levels.
 * XDA / XCL are the MPU-6050's auxiliary I2C master (for a magnetometer) - not
   simulated.
 * The real sensor has noise, offsets and temperature drift (calibrate it); the
   model gives exact values.

THE TEST TOOLS (MPU6050 Advance, Test tab) - what they really measure
Every tool runs on the live model with your sketch: it changes the sensor's
inputs (and restores them) and watches the I2C reads your Arduino really makes -
it never talks to your Arduino. Each tool shows one "Good for:" line and one
line on how it measures.
  I2C check       Good for: checking that the MPU6050 answers and what your
                  sketch really wrote into it. The registers read live and
                  decoded (WHO_AM_I, PWR_MGMT_1, SMPLRT_DIV, CONFIG, GYRO_CONFIG,
                  ACCEL_CONFIG, MOT_THR, MOT_DUR, INT_PIN_CFG, INT_ENABLE,
                  INT_STATUS, USER_CTRL, FIFO_EN, PWR_MGMT_2, FIFO_COUNT), the
                  address and the AD0 level, transactions, bytes, NACKs, the
                  measured SCL clock and the last transactions decoded (repeats
                  folded). With the demo: "write CONFIG = 04" (21 Hz), "write
                  ACCEL_CONFIG = 18" (+-16 g), "read ACCEL_XOUT_H -> 14 bytes".
  Timing          Good for: seeing how often new data exists and whether your
                  sketch reads it in time. Records for 1, 3 or 10 s every sample
                  the MPU6050 makes and every read of the data registers: the
                  output period (avg / min / max), the sketch's read period, the
                  data age at each read, reads of the same sample twice, and the
                  datasheet formula with your registers (sample rate = 1 kHz with
                  the DLPF on, 8 kHz off, / (1 + SMPLRT_DIV)). With the demo: a
                  sample every 1.000 ms, the sketch reads every 500 ms.
  Step response   Good for: seeing how quickly a change reaches your sketch -
                  conversion, filter and read period together. Steps the tilt
                  (0 -> 45 degrees), the rotation (GZ 0 -> 250 deg/s) or the
                  temperature (25 -> 40 C) 1, 3 or 5 times (1.5 s each) and plots
                  every reading your sketch made; per step: the first reading
                  that shows it (10 %), 90 % and settled (2 %). With the demo's
                  500 ms reads the step shows within one read; with RATE 200 and
                  FILTER 5 you can watch the 19 ms filter delay in the readings.
  Orientation     Good for: checking that your pitch / roll maths and the motion
                  interrupt work in every position. Holds the sensor flat, nose
                  up 45, nose down 30, rolled right 45, on its edge and upside
                  down (2.2 s each) and computes the pitch / roll from the
                  accelerometer values your sketch read (atan2) - with a small
                  horizon per position - then shakes it for 1.5 s and counts the
                  motion interrupts (INT_STATUS MOT_INT). With the demo: 6 / 6
                  within 0.2 degrees, the shake fires the motion interrupt after
                  MOTION ON.

THE DEMO SKETCH ON THE SERIAL MONITOR (MPU6050_Demo v1.1)
  HELP                    the command list
  STATUS                  ranges, filter, print period, motion detection, alarm
  RANGE 2|4|8|16          accelerometer range (+-g)
  GYRO 250|500|1000|2000  gyro range (+-deg/s)
  FILTER 260|184|94|44|21|10|5   the digital low-pass filter (Hz)
  RATE ms                 print period, 100 .. 10000 ms (default 500)
  MOTION ON [thr] | OFF   the motion interrupt (high-pass 0.63 Hz, threshold
                          default 10, 20 ms, latched); "Motion detected!"
  TILT ON | OFF           the tilt line
Monitor quick buttons in the demo: STATUS, MOTION ON, RATE 200, HELP.
Every line the sketch prints has at most 80 characters (it fits the Serial Monitor's
Simple interface); longer answers are split, the second line indented.

EXPECTED MONITOR OUTPUT (U3 and U4)
  TEP MPU6050 - drag acceleration, gyro and temperature controls.
  TEP MPU6050 Demo v1.1 - type HELP in the Serial Monitor
  Accel g: 0.00, 0.00, 1.00
  Gyro deg/s: 0.0, 0.0, 0.0 | T: 25.0 C
  Tilt: pitch 0.0, roll 0.0 deg
After ROLL 45 on the panel:
  Accel g: 0.00, 0.71, 0.71
  Gyro deg/s: 0.0, 0.0, 0.0 | T: 25.0 C
  Tilt: pitch 0.0, roll 45.0 deg
  Tilt alarm: ON (more than 30 deg)
After MOTION ON and SHAKE:
  Motion detection ON: threshold 10, 20 ms
  Motion detected!

PROPERTIES (double-click the sensor > Edit Properties; the same on Simple and
Advance - the v1.0 properties)
  AX, AY, AZ      acceleration in g, -16 .. 16 (default 0, 0, 1 = lying flat)
  GX, GY, GZ      rotation in deg/s, -2000 .. 2000 (default 0)
  TEMPERATURE     die temperature in C, -40 .. 85 (default 25)
The panel style is chosen by the device (Simple / Advance), not by a property.
The Advance window settings (theme, text size, open at Run, size) are on its
Settings page. The demo's Serial Monitors: BAUD 9600, THEME TEPDARK, AUTOOPEN
YES, QUICK1-4 as above (see the Serial Monitor's article for all its
properties).

LINKS.INI (OPTIONAL)
The Help page cards of the Advance device open web pages. To point them
somewhere else without a new DLL, put a text file named links.ini next to
TEPMPU6050.DLL with lines KEY=URL, for example:
  ARTICLE=https://www.theengineeringprojects.com/...
Keys: WEBSITE, FORUM, BUG_REPORT, FEATURE_REQUEST, ARTICLE, USER_GUIDE,
UPDATE_CHECK, DONATE. Only http:// and https:// links are used; lines starting
with # are comments.

TROUBLESHOOTING
* "MPU6050 not found. Check power, A4/SDA, A5/SCL and AD0.": check VCC / GND (the
  PWR LED must be lit and the board shows "I2C 0x68"), SDA -> A4, SCL -> A5, and
  that AD0 matches the address in begin() (0x68 = AD0 low).
* The values do not change: the blue I2C LED must flash with every read; the
  sliders change the physical input - the sketch sees it at its next read (and
  through the low-pass filter: FILTER 5 delays it by 19 ms).
* Gravity: lying flat the sensor reads +1 g on Z. Setting AX = AY = AZ = 0 is
  free fall.
* "Motion detected!" never comes: type MOTION ON first; the motion detector
  only sees changes (the high-pass filter), so a constant tilt is not motion -
  click SHAKE.
* The part is not simulated / no panel: TEPMPU6050.DLL is missing from MODELS
  and from the project folder. No monitor window: TEPSERIALMON.DLL is missing, or
  click OPEN MONITOR on the monitor part.
* Advance: the pop-up does not appear - click OPEN PANEL on the board, use
  Proteus's Debug menu, or turn "Open the panel at Run" on its Settings page
  back on.
* Simple: the red X does not close the panel / the board looks like v1.0 - the
  design still holds the v1.0 symbol; replace TEPMPU6050.LIB, delete
  TEPMPU6050.IDX and re-pick the part.
* Your own sketch uses SoftwareSerial to receive: Proteus 8.5 cannot receive
  with SoftwareSerial (pin-change interrupts are not simulated) - use the
  hardware Serial (as the demo does) or AltSoftSerial.

BUG REPORTS AND FEATURE REQUESTS
Please post them in our forum with a screenshot, the Serial Monitor text, the
simulation log and (Advance) the Copy diagnostics text:
  https://www.theengineeringprojects.com/forum/category/mpu6050-proteus-library

SUPPORT US
This library is free. If it saves you time, please support our work:
  https://www.theengineeringprojects.com/donate

WEBSITE
  https://www.theengineeringprojects.com/

LICENCES AND THIRD-PARTY NOTES
* The MPU6050 model (TEPMPU6050.DLL), the symbols and artwork and the TEP Serial
  Monitor Advance (TEPSERIALMON.LIB / .DLL) are made by The Engineering
  Projects. The model is an independent implementation written from the
  MPU-6000 / MPU-6050 product specification and register map; it contains no
  InvenSense code. The models use only standard Windows libraries; no Visual
  C++ redistributable is needed.
* TEP Arduino UNO V3 library (ArduinoV3TEP.LIB / .IDX): The Engineering
  Projects, https://www.theengineeringprojects.com/2023/10/arduino-library-for-proteus-v30.html
* Adafruit MPU6050 Arduino library 2.2.9 by Adafruit Industries, shipped
  unmodified in Arduino Code\libraries\Adafruit_MPU6050: BSD licence, see
  Arduino Code\libraries\Adafruit_MPU6050\license.txt -
  https://github.com/adafruit/Adafruit_MPU6050
* Adafruit BusIO 1.17.4 by Adafruit Industries, shipped unmodified in Arduino
  Code\libraries\Adafruit_BusIO: MIT licence, see
  Arduino Code\libraries\Adafruit_BusIO\LICENSE - https://github.com/adafruit/Adafruit_BusIO
* Adafruit Unified Sensor 1.1.15 by Adafruit Industries, shipped unmodified in
  Arduino Code\libraries\Adafruit_Unified_Sensor: Apache License 2.0, see
  Arduino Code\libraries\Adafruit_Unified_Sensor\LICENSE.txt -
  https://github.com/adafruit/Adafruit_Sensor
* Arduino AVR core 1.8.6 (with its Wire and SPI libraries): the .hex file is
  built from the demo sketch, the Adafruit libraries and the Arduino AVR core,
  which includes LGPL-licensed code. Its source code is available at
  https://github.com/arduino/ArduinoCore-avr/tree/1.8.6
* InvenSense and MPU-6050 are trademarks of TDK InvenSense; their use here
  identifies compatible devices, not endorsement. Proteus is a product of
  Labcenter Electronics and is not included. Arduino is a trademark of Arduino
  SA.

REBUILDING THE FIRMWARE (OPTIONAL)
The HEX file is supplied; Arduino IDE is not needed to run the demo. To edit the
sketch, install the "Adafruit MPU6050" library (it installs Adafruit BusIO and
Adafruit Unified Sensor) from the Library Manager or copy the three folders in
Arduino Code\libraries into your sketchbook libraries folder, open Arduino Code\
MPU6050_Demo\MPU6050_Demo.ino, select Arduino Uno and use Sketch > Export
Compiled Binary. Replace the simulation's .hex with the exported HEX.

MODEL SCOPE AND LIMITS
Modelled: I2C (0x68 / 0x69 by AD0, standard and fast mode), WHO_AM_I 0x68,
PWR_MGMT_1 (reset, sleep, clock select), PWR_MGMT_2 (axes in standby read 0),
SMPLRT_DIV with the 8 / 1 kHz gyro output rate, CONFIG DLPF_CFG with the delay
(first-order lag), GYRO_CONFIG / ACCEL_CONFIG ranges, the temperature (the
datasheet formula T = raw / 340 + 36.53), the FIFO (accel, temp, gyro; 1024
bytes, count, overflow), INT_PIN_CFG / INT_ENABLE / INT_STATUS (data ready, FIFO
overflow, motion), the motion detector (MOT_THR, MOT_DUR, the high-pass filter),
SIGNAL_PATH_RESET, USER_CTRL (FIFO enable / reset).
Not modelled: the DMP (motion processing firmware), the auxiliary I2C master
(XDA / XCL), the self-test, the offset registers, the cycle / low-power wake-up
modes, zero-motion and free-fall detection, noise, offsets and drift; the
MOT_THR scale (2 mg / LSB) is a model value (the current register map does not
state it).

VERSION
TEP MPU6050 library v1.1 (8 Oct 2026). Devices MPU6050TEP (Simple) and
MPU6050ADVTEP (Advance), files TEPMPU6050.LIB / TEPMPU6050.DLL (the TEP I2C
sensor family model 1.1). Demo sketch MPU6050_Demo v1.1. Demo monitor: TEP Serial
Monitor Advance v1.0.1 (SERIALMONTEP).
v1.0 (29 Sep 2026): first release (MPU6050TEP, the slider panel, TEPMPU6050.DLL,
a one-UNO demo with a Virtual Terminal).
