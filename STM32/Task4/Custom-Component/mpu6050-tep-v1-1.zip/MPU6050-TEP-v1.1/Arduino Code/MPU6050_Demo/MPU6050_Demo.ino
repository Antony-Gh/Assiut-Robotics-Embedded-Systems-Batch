// TEP MPU6050 Demo v1.1 - The Engineering Projects (www.TheEngineeringProjects.com)
// MPU6050 (GY-521) on an Arduino UNO: SDA -> A4, SCL -> A5, AD0 -> GND (address 0x68), VCC / GND.
// Reads acceleration, rotation and temperature with the Adafruit MPU6050 library and prints them every 500 ms (the v1.0
// lines), plus the tilt (pitch / roll) the accelerometer shows. The LED on A0 is a tilt alarm: on while the board leans more
// than 30 degrees, and for 1 s after the motion interrupt fired.
// Serial Monitor (9600 baud) commands: HELP, STATUS, RANGE 2|4|8|16, GYRO 250|500|1000|2000, FILTER 260|184|94|44|21|10|5,
// RATE <ms>, MOTION ON [threshold] | OFF, TILT ON | OFF.
#include <Wire.h>
#include <Adafruit_MPU6050.h>
Adafruit_MPU6050 sensor;
bool ready=false;

const uint8_t LED_PIN=A0;
unsigned long readEvery=500, lastRead=0, lastPoll=0, ledUntil=0;
bool motionOn=false, tiltLine=true, alarmOn=false;
uint8_t motionThreshold=10;
char line[32]; uint8_t lineLen=0;

int accelRangeG() { switch(sensor.getAccelerometerRange()) { case MPU6050_RANGE_2_G: return 2; case MPU6050_RANGE_4_G: return 4; case MPU6050_RANGE_8_G: return 8; default: return 16; } }
int gyroRangeDps() { switch(sensor.getGyroRange()) { case MPU6050_RANGE_250_DEG: return 250; case MPU6050_RANGE_500_DEG: return 500; case MPU6050_RANGE_1000_DEG: return 1000; default: return 2000; } }
int filterHz() {
  switch(sensor.getFilterBandwidth()) { case MPU6050_BAND_260_HZ: return 260; case MPU6050_BAND_184_HZ: return 184; case MPU6050_BAND_94_HZ: return 94;
    case MPU6050_BAND_44_HZ: return 44; case MPU6050_BAND_21_HZ: return 21; case MPU6050_BAND_10_HZ: return 10; default: return 5; }
}

void help() {
  Serial.println(F("Commands: HELP, STATUS, RANGE 2|4|8|16, GYRO 250|500|1000|2000,"));
  Serial.println(F("  FILTER 260|184|94|44|21|10|5, RATE ms, MOTION ON [thr] | OFF, TILT ON | OFF"));
}
void status() {
  Serial.print(F("Status: +-")); Serial.print(accelRangeG()); Serial.print(F(" g, +-")); Serial.print(gyroRangeDps());
  Serial.print(F(" deg/s, filter ")); Serial.print(filterHz()); Serial.print(F(" Hz, every ")); Serial.print(readEvery);
  Serial.println(F(" ms")); Serial.print(F("  motion ")); Serial.print(motionOn ? F("ON") : F("OFF")); Serial.print(F(", tilt alarm ")); Serial.println(alarmOn ? F("ON") : F("off"));
}
void command(char* s) {
  for(char* p=s; *p; ++p) if(*p>='a' && *p<='z') *p-=32;
  char* arg=strchr(s,' ');
  if(arg) { *arg++=0; while(*arg==' ') ++arg; }
  const long n=arg ? atol(arg) : 0;
  if(!strcmp(s,"HELP")) help();
  else if(!strcmp(s,"STATUS")) status();
  else if(!ready) Serial.println(F("MPU6050 not found - check the wiring"));
  else if(!strcmp(s,"RANGE")) {
    if(n==2) sensor.setAccelerometerRange(MPU6050_RANGE_2_G); else if(n==4) sensor.setAccelerometerRange(MPU6050_RANGE_4_G);
    else if(n==8) sensor.setAccelerometerRange(MPU6050_RANGE_8_G); else if(n==16) sensor.setAccelerometerRange(MPU6050_RANGE_16_G);
    else { Serial.println(F("RANGE 2, 4, 8 or 16")); return; }
    Serial.print(F("Accelerometer range: +-")); Serial.print(accelRangeG()); Serial.println(F(" g"));
  } else if(!strcmp(s,"GYRO")) {
    if(n==250) sensor.setGyroRange(MPU6050_RANGE_250_DEG); else if(n==500) sensor.setGyroRange(MPU6050_RANGE_500_DEG);
    else if(n==1000) sensor.setGyroRange(MPU6050_RANGE_1000_DEG); else if(n==2000) sensor.setGyroRange(MPU6050_RANGE_2000_DEG);
    else { Serial.println(F("GYRO 250, 500, 1000 or 2000")); return; }
    Serial.print(F("Gyro range: +-")); Serial.print(gyroRangeDps()); Serial.println(F(" deg/s"));
  } else if(!strcmp(s,"FILTER")) {
    if(n==260) sensor.setFilterBandwidth(MPU6050_BAND_260_HZ); else if(n==184) sensor.setFilterBandwidth(MPU6050_BAND_184_HZ);
    else if(n==94) sensor.setFilterBandwidth(MPU6050_BAND_94_HZ); else if(n==44) sensor.setFilterBandwidth(MPU6050_BAND_44_HZ);
    else if(n==21) sensor.setFilterBandwidth(MPU6050_BAND_21_HZ); else if(n==10) sensor.setFilterBandwidth(MPU6050_BAND_10_HZ);
    else if(n==5) sensor.setFilterBandwidth(MPU6050_BAND_5_HZ);
    else { Serial.println(F("FILTER 260, 184, 94, 44, 21, 10 or 5")); return; }
    Serial.print(F("Filter: ")); Serial.print(filterHz()); Serial.println(F(" Hz"));
  } else if(!strcmp(s,"RATE")) {
    if(n<100 || n>10000) { Serial.println(F("RATE 100 .. 10000 ms")); return; }
    readEvery=n; Serial.print(F("Printing every ")); Serial.print(readEvery); Serial.println(F(" ms"));
  } else if(!strcmp(s,"MOTION")) {
    if(arg && !strncmp(arg,"OFF",3)) { sensor.setMotionInterrupt(false); motionOn=false; Serial.println(F("Motion detection OFF")); return; }
    if(!arg || strncmp(arg,"ON",2)) { Serial.println(F("MOTION ON [threshold] or MOTION OFF")); return; }
    const char* t=strchr(arg,' ');
    if(t) { const long v=atol(t); if(v>=1 && v<=255) motionThreshold=v; }
    sensor.setHighPassFilter(MPU6050_HIGHPASS_0_63_HZ);
    sensor.setMotionDetectionThreshold(motionThreshold);
    sensor.setMotionDetectionDuration(20);
    sensor.setInterruptPinLatch(true);
    sensor.setInterruptPinPolarity(false);
    sensor.setMotionInterrupt(true);
    motionOn=true;
    Serial.print(F("Motion detection ON: threshold ")); Serial.print(motionThreshold); Serial.println(F(", 20 ms"));
  } else if(!strcmp(s,"TILT")) {
    tiltLine=!(arg && !strncmp(arg,"OFF",3));
    Serial.print(F("Tilt line ")); Serial.println(tiltLine ? F("ON") : F("OFF"));
  } else { Serial.print(F("Unknown command: ")); Serial.print(s); Serial.println(F(" - type HELP")); }
}
void readSerial() {
  while(Serial.available()) {
    const char c=Serial.read();
    if(c=='\r' || c=='\n') { if(lineLen) { line[lineLen]=0; command(line); lineLen=0; } }
    else if(lineLen<sizeof line-1) line[lineLen++]=c;
  }
}

void setup() {
  Serial.begin(9600); Wire.begin(); Wire.setWireTimeout(25000,true);
  pinMode(LED_PIN,OUTPUT); digitalWrite(LED_PIN,LOW);
  ready=sensor.begin(0x68);
  if(!ready) { Serial.println(F("MPU6050 not found. Check power, A4/SDA, A5/SCL and AD0.")); return; }
  sensor.setAccelerometerRange(MPU6050_RANGE_16_G);
  sensor.setGyroRange(MPU6050_RANGE_2000_DEG);
  sensor.setFilterBandwidth(MPU6050_BAND_21_HZ);
  Serial.println(F("TEP MPU6050 - drag acceleration, gyro and temperature controls."));
  Serial.println(F("TEP MPU6050 Demo v1.1 - type HELP in the Serial Monitor"));
}
void loop() {
  readSerial();
  if(!ready) return;
  const unsigned long now=millis();
  if(motionOn && now-lastPoll>=50) {
    lastPoll=now;
    if(sensor.getMotionInterruptStatus()) { Serial.println(F("Motion detected!")); ledUntil=now+1000; }
  }
  if(now-lastRead>=readEvery) {
    lastRead=now;
    sensors_event_t a,g,t; sensor.getEvent(&a,&g,&t);
    Serial.print(F("Accel g: ")); Serial.print(a.acceleration.x/9.80665,2);
    Serial.print(F(", ")); Serial.print(a.acceleration.y/9.80665,2);
    Serial.print(F(", ")); Serial.println(a.acceleration.z/9.80665,2);
    Serial.print(F("Gyro deg/s: ")); Serial.print(g.gyro.x*57.29578,1);
    Serial.print(F(", ")); Serial.print(g.gyro.y*57.29578,1);
    Serial.print(F(", ")); Serial.print(g.gyro.z*57.29578,1);
    Serial.print(F(" | T: ")); Serial.print(t.temperature,1); Serial.println(F(" C"));
    const float ax=a.acceleration.x, ay=a.acceleration.y, az=a.acceleration.z;
    const float pitch=atan2(-ax,sqrt(ay*ay+az*az))*57.29578, roll=atan2(ay,az)*57.29578;
    if(tiltLine) { Serial.print(F("Tilt: pitch ")); Serial.print(pitch,1); Serial.print(F(", roll ")); Serial.print(roll,1); Serial.println(F(" deg")); }
    const bool tilted=fabs(pitch)>30 || fabs(roll)>30;
    if(tilted!=alarmOn) { alarmOn=tilted; Serial.println(alarmOn ? F("Tilt alarm: ON (more than 30 deg)") : F("Tilt alarm: off")); }
  }
  digitalWrite(LED_PIN,(alarmOn || millis()<ledUntil) ? HIGH : LOW);
}
