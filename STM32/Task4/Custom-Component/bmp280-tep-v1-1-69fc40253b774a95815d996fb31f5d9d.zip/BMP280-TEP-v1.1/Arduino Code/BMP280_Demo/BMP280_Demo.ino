// TEP BMP280 Demo v1.1 - The Engineering Projects (www.TheEngineeringProjects.com)
// BMP280 (GY-BMP280) on an Arduino UNO: SDA -> A4, SCL -> A5, SDO -> GND (address 0x76), CSB -> VCC (I2C mode), VCC / GND.
// Reads temperature and pressure with the Adafruit BMP280 library every 500 ms (the v1.0 line) plus the altitude. The LED on A0
// is a low-pressure warning: on while the pressure is below 1000 hPa (a storm - or you climbed).
// Serial Monitor (9600 baud) commands: HELP, STATUS, SEA <hPa>, ALT (this place = 0 m), MODE NORMAL | FORCED,
// OS 1|2|4|8|16, FILTER OFF|2|4|8|16, STANDBY <ms>.
#include <Wire.h>
#include <Adafruit_BMP280.h>
Adafruit_BMP280 sensor;
bool ready=false;

const uint8_t LED_PIN=A0;
float seaLevel=1013.25;
bool forced=false, lowOn=false;
uint8_t osP=1, filt=0; uint16_t standbyMs=125;
unsigned long lastRead=0;
char line[32]; uint8_t lineLen=0;

Adafruit_BMP280::sensor_sampling sampling(uint8_t x) {
  switch(x) { case 1: return Adafruit_BMP280::SAMPLING_X1; case 2: return Adafruit_BMP280::SAMPLING_X2; case 4: return Adafruit_BMP280::SAMPLING_X4;
    case 8: return Adafruit_BMP280::SAMPLING_X8; default: return Adafruit_BMP280::SAMPLING_X16; }
}
Adafruit_BMP280::sensor_filter filter(uint8_t f) {
  switch(f) { case 2: return Adafruit_BMP280::FILTER_X2; case 4: return Adafruit_BMP280::FILTER_X4; case 8: return Adafruit_BMP280::FILTER_X8;
    case 16: return Adafruit_BMP280::FILTER_X16; default: return Adafruit_BMP280::FILTER_OFF; }
}
Adafruit_BMP280::standby_duration standby(uint16_t ms) {
  if(ms<=1) return Adafruit_BMP280::STANDBY_MS_1; if(ms<=63) return Adafruit_BMP280::STANDBY_MS_63; if(ms<=125) return Adafruit_BMP280::STANDBY_MS_125;
  if(ms<=250) return Adafruit_BMP280::STANDBY_MS_250; if(ms<=500) return Adafruit_BMP280::STANDBY_MS_500; if(ms<=1000) return Adafruit_BMP280::STANDBY_MS_1000;
  if(ms<=2000) return Adafruit_BMP280::STANDBY_MS_2000; return Adafruit_BMP280::STANDBY_MS_4000;
}
void apply() {     // SLEEP first: the BMP280 may ignore a config (filter / standby) write in NORMAL mode (datasheet 5.4.6)
  sensor.setSampling(Adafruit_BMP280::MODE_SLEEP, Adafruit_BMP280::SAMPLING_X1, sampling(osP), filter(filt), standby(standbyMs));
  sensor.setSampling(forced ? Adafruit_BMP280::MODE_FORCED : Adafruit_BMP280::MODE_NORMAL, Adafruit_BMP280::SAMPLING_X1, sampling(osP), filter(filt), standby(standbyMs));
}
void help() {
  Serial.println(F("Commands: HELP, STATUS, SEA hPa, ALT, MODE NORMAL|FORCED, OS 1|2|4|8|16,"));
  Serial.println(F("  FILTER OFF|2|4|8|16, STANDBY ms (1 63 125 250 500 1000 2000 4000)"));
}
void status() {
  Serial.print(F("Status: ")); Serial.print(forced ? F("FORCED") : F("NORMAL")); Serial.print(F(" mode, pressure x")); Serial.print(osP);
  Serial.print(F(", filter ")); if(filt) Serial.print(filt); else Serial.print(F("OFF"));
  Serial.print(F(", standby ")); Serial.print(standbyMs); Serial.println(F(" ms")); Serial.print(F("  sea level ")); Serial.print(seaLevel,2); Serial.println(F(" hPa"));
}
void command(char* s) {
  for(char* p=s; *p; ++p) if(*p>='a' && *p<='z') *p-=32;
  char* arg=strchr(s,' ');
  if(arg) { *arg++=0; while(*arg==' ') ++arg; }
  if(!strcmp(s,"HELP")) help();
  else if(!strcmp(s,"STATUS")) status();
  else if(!ready) Serial.println(F("BMP280 not found - check the wiring"));
  else if(!strcmp(s,"SEA")) {
    const float v=arg ? atof(arg) : 0;
    if(v<300 || v>1100) { Serial.println(F("SEA 300 .. 1100 hPa")); return; }
    seaLevel=v; Serial.print(F("Sea level pressure: ")); Serial.print(seaLevel,2); Serial.println(F(" hPa"));
  } else if(!strcmp(s,"ALT")) {
    if(forced) sensor.takeForcedMeasurement();
    seaLevel=sensor.readPressure()/100.0;
    Serial.print(F("Altitude zero here: sea level set to ")); Serial.print(seaLevel,2); Serial.println(F(" hPa"));
  } else if(!strcmp(s,"MODE")) {
    if(arg && !strncmp(arg,"FORCED",6)) forced=true; else if(arg && !strncmp(arg,"NORMAL",6)) forced=false;
    else { Serial.println(F("MODE NORMAL or MODE FORCED")); return; }
    apply(); Serial.print(F("Mode: ")); Serial.println(forced ? F("FORCED (one measurement per reading)") : F("NORMAL (continuous)"));
  } else if(!strcmp(s,"OS")) {
    const int n=arg ? atoi(arg) : 0;
    if(n!=1 && n!=2 && n!=4 && n!=8 && n!=16) { Serial.println(F("OS 1, 2, 4, 8 or 16")); return; }
    osP=n; apply(); Serial.print(F("Pressure oversampling: x")); Serial.println(osP);
  } else if(!strcmp(s,"FILTER")) {
    const int n=arg ? atoi(arg) : 0;
    if(n!=0 && n!=2 && n!=4 && n!=8 && n!=16) { Serial.println(F("FILTER OFF, 2, 4, 8 or 16")); return; }
    filt=n; apply(); Serial.print(F("IIR filter: ")); if(filt) Serial.println(filt); else Serial.println(F("OFF"));
  } else if(!strcmp(s,"STANDBY")) {
    const long n=arg ? atol(arg) : -1;
    if(n<0 || n>4000) { Serial.println(F("STANDBY 1 .. 4000 ms")); return; }
    standbyMs=n; apply(); Serial.print(F("Standby: ")); Serial.print(standbyMs); Serial.println(F(" ms"));
  } else { Serial.print(F("Unknown command: ")); Serial.print(s); Serial.println(F(" - type HELP")); }
}
void readSerial() {
  while(Serial.available()) {
    const char c=Serial.read();
    if(c=='\r' || c=='\n') { if(lineLen) { line[lineLen]=0; command(line); lineLen=0; } }
    else if(lineLen<sizeof line-1) line[lineLen++]=c;
  }
}

void setup() {
  Serial.begin(9600); Wire.begin(); Wire.setWireTimeout(25000,true);
  pinMode(LED_PIN,OUTPUT); digitalWrite(LED_PIN,LOW);
  ready=sensor.begin(0x76);
  if(!ready) { Serial.println(F("BMP280 not found. Check SDA, SCL, SDO/GND and CSB/VCC.")); return; }
  apply();   // the v1.0 settings: NORMAL, x1 / x1, filter off, 125 ms standby
  Serial.println(F("TEP BMP280 - drag the temperature and pressure sliders.")); delay(100);
  Serial.println(F("TEP BMP280 Demo v1.1 - type HELP in the Serial Monitor"));
}
void loop() {
  readSerial();
  if(!ready) { delay(1); return; }
  if(millis()-lastRead<500) return;
  lastRead=millis();
  if(forced) sensor.takeForcedMeasurement();
  const float t=sensor.readTemperature(), p=sensor.readPressure()/100.0;
  Serial.print(F("Temperature: ")); Serial.print(t,1);
  Serial.print(F(" C | Pressure: ")); Serial.print(p,1); Serial.println(F(" hPa"));
  const float alt=44330.0*(1.0-pow(p/seaLevel,0.1903));
  Serial.print(F("Altitude: ")); Serial.print(alt,1); Serial.print(F(" m (sea level ")); Serial.print(seaLevel,2); Serial.println(F(" hPa)"));
  const bool low=p<1000;
  if(low!=lowOn) { lowOn=low; Serial.println(lowOn ? F("Low pressure: below 1000 hPa (LED on)") : F("Low pressure: off")); }
  digitalWrite(LED_PIN,lowOn ? HIGH : LOW);
}
